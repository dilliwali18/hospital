<?php
            if (isset($_POST['submit'])){
                $msgtxt = "";
                $msgtxt = $msgtxt . "<br/>";
                $msgtxt = $msgtxt . "Name:  " . $_POST['fname'] . "<br/>";
                $msgtxt = $msgtxt . "Tel :  " . $_POST['mobilenumber'] . "<br/>";
				$msgtxt = $msgtxt . "Date :  " . $_POST['date'] . "<br/>";
				$msgtxt = $msgtxt . "Message :  " . $_POST['message'] . "<br/>";
				

                $fromemail = 'info@srlbandra.com';
                $to = 'diwinesmile@gmail.com';
                
                
                $subject = "Dr.Shraddha Chaugule Divine Smile Diagnostic Center";
                $headers = 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
                $headers .= "From:". $_POST['fname'] . '' . $_POST['email'] .'<'. $fromemail . '>'."\r\n";
                if ($to && $subject) {
                    mail($to, $subject, $msgtxt, $headers);
                 ?>
                   <script>
        alert('Thank You For Sending email');
        location.href="index.html";
        </script>
<?php
                }
            }
            
            ?>