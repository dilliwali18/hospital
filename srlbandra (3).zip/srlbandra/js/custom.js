
// $('body').on('mouseenter mouseleave','.nav-item',function(e){
			// if ($(window).width() > 750) {
				// var _d=$(e.target).closest('.nav-item');_d.addClass('show');
				// setTimeout(function(){
				// _d[_d.is(':hover')?'addClass':'removeClass']('show');
				// },1);
			// }
// });	

$(function() {
		var header = $(".start-style");
		$(window).scroll(function() {    
			var scroll = $(window).scrollTop();
		
			if (scroll >= 10) {
				header.removeClass('start-style').addClass("scroll-on");
			} else {
				header.removeClass("scroll-on").addClass('start-style');
			}
		});
});	





$('#slider').owlCarousel({
    loop:true,
    margin:10,
    dots:true,
    nav:false,
    mouseDrag:false,
    autoplay:false,
    animateOut: 'slideOutUp',
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
});

$('#testing').owlCarousel({
	items:3,
	slideBy: 3,
	margin:20,
    loop:true,
	dots:true,
    nav:false,
    mouseDrag:false,
    autoplay:false,
	autoplayTimeout: 6500,
	autoplaySpeed: 800,
	slideSpeed : 3000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3,
			
        }
    }
});


$('#feature-package').owlCarousel({
	items:3,
	slideBy: 3,
	margin:20,
    loop:true,
	dots:false,
    nav:true,
	navText: ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"],
    mouseDrag:false,
    autoplay:false,
	autoplayTimeout: 6500,
	autoplaySpeed: 800,
	slideSpeed : 3000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3,
			
        }
    }
});



$('#testi').owlCarousel({
	
	margin:20,
    loop:true,
	center:true,
	dots:true,
    nav:false,
    mouseDrag:true,
    autoplay:true,
	autoplayTimeout: 6500,
	autoplaySpeed: 800,
	slideSpeed : 3000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3,
			
        }
    }
});

